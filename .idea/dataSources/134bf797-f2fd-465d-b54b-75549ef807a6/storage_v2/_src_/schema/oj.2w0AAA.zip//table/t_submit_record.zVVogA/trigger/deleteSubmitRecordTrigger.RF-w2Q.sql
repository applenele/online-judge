CREATE TRIGGER deleteSubmitRecordTrigger
  AFTER DELETE
  ON t_submit_record
  FOR EACH ROW
  BEGIN
    SET @submitID = OLD.submit_id;
    /*删除该提交下的详细评测结果*/
    DELETE FROM t_judge_detail WHERE t_judge_detail.submit_id=@submitID;
    /*删除该提交下的编译结果*/
    DELETE FROM t_compile_info WHERE t_compile_info.submit_id=@submitID;
    /*删除该记录下的错误信息*/
    DELETE FROM t_system_error WHERE t_system_error.submit_id=@submitID;
  END;

