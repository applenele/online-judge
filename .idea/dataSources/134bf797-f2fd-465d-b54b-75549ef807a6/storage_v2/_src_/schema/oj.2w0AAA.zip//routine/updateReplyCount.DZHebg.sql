CREATE PROCEDURE updateReplyCount(IN postID INT)
  BEGIN
    DECLARE cnt INT;
    SELECT count(post_id) INTO cnt FROM t_discuss WHERE post_id!=root_id AND post_id!=direct_fid AND root_id=postID;
    UPDATE t_discuss SET reply=cnt WHERE post_id=postID;
  END;

