CREATE TRIGGER updateSubmitRecordTrigger
  AFTER UPDATE
  ON t_submit_record
  FOR EACH ROW
  BEGIN
    IF NEW.result='Accepted' THEN
      UPDATE t_user    SET accepted=(SELECT count(DISTINCT problem_id) FROM t_submit_record WHERE    user_id=NEW.user_id    AND result='Accepted');
      UPDATE t_problem SET accepted=(SELECT count(DISTINCT user_id)    FROM t_submit_record WHERE problem_id=NEW.problem_id AND result='Accepted');
    END IF;
  END;

