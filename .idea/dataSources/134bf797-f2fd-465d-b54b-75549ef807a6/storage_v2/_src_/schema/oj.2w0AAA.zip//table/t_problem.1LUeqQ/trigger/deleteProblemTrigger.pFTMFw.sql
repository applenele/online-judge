CREATE TRIGGER deleteProblemTrigger
  AFTER DELETE
  ON t_problem
  FOR EACH ROW
  BEGIN
    /*获取被删除提交的ID*/
    SET @problemID = OLD.problem_id;
    /*删除该题目的测试点*/
    DELETE FROM t_test_point WHERE t_test_point.problem_id=@problemID;
    /*删除所有关于该题目的提交记录*/
    DELETE FROM t_submit_record WHERE t_submit_record.problem_id=@problemID;
    /*从所有比赛中删除这个题目*/
    DELETE FROM t_contest_problem WHERE t_contest_problem.problem_id=@problemID;
  END;

