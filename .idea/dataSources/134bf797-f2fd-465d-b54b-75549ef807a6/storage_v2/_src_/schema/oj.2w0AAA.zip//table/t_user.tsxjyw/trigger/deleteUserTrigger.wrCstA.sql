CREATE TRIGGER deleteUserTrigger
  AFTER DELETE
  ON t_user
  FOR EACH ROW
  BEGIN
    SET @userID = OLD.user_id;
    /*删除该该用户的提交记录*/
    DELETE FROM t_submit_record WHERE t_submit_record.user_id=@userID;
    /*删除该用户的讨论记录*/
    DELETE FROM t_discuss WHERE t_discuss.user_id=@userID;
    /*删除该用户的比赛记录*/
    DELETE FROM t_contest_user WHERE t_contest_user.user_id=@userID;
  END;

