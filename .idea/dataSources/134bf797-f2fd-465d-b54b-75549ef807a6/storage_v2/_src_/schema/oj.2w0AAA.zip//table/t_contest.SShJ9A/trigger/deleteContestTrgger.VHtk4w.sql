CREATE TRIGGER deleteContestTrgger
  AFTER DELETE
  ON t_contest
  FOR EACH ROW
  BEGIN
    /*获取被删除比赛的ID*/
    SET @contestID = OLD.contest_id;
    /*删除比赛用户*/
    DELETE FROM t_contest_user WHERE t_contest_user.contest_id=@contestID;
    /*删除比赛题目*/
    DELETE FROM t_contest_problem WHERE t_contest_problem.contest_id=@contestID;
    /*删除该比赛下的所有提交代码*/
    DELETE FROM t_submit_record WHERE t_submit_record.contest_id=@contestID;
  END;

