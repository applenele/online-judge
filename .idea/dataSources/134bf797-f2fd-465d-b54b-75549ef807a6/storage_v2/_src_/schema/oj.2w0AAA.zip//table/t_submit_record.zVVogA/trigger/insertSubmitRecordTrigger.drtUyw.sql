CREATE TRIGGER insertSubmitRecordTrigger
  AFTER INSERT
  ON t_submit_record
  FOR EACH ROW
  BEGIN
    /*更新题目和用户的提交次数*/
    UPDATE t_problem SET submitted=submit_id+1 WHERE problem_id=NEW.problem_id;
    UPDATE t_user SET submitted=submitted+1 WHERE user_id=NEW.user_id;
  END;

