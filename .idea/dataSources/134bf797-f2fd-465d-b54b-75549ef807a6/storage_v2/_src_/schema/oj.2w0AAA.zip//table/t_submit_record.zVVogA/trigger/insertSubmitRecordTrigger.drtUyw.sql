CREATE TRIGGER insertSubmitRecordTrigger
  AFTER INSERT
  ON t_submit_record
  FOR EACH ROW
  BEGIN
    /*更新题目和用户的提交次数*/
    UPDATE t_problem SET submitted=(SELECT count(submit_id) FROM t_submit_record WHERE t_submit_record.problem_id=NEW.problem_id) WHERE problem_id=NEW.problem_id;
    UPDATE t_user    SET submitted=(SELECT count(submit_id) FROM t_submit_record WHERE    t_submit_record.user_id=NEW.user_id)    WHERE    user_id=NEW.user_id;
  END;

