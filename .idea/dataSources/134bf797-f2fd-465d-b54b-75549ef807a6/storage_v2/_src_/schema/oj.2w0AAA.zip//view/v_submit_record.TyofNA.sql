CREATE VIEW v_submit_record AS
  SELECT
    `submit`.`submit_id`       AS `submit_id`,
    `submit`.`contest_id`      AS `contest_id`,
    `oj`.`t_contest`.`title`   AS `contest_title`,
    `submit`.`problem_id`      AS `problem_id`,
    `oj`.`t_problem`.`title`   AS `problem_title`,
    `submit`.`user_id`         AS `user_id`,
    `oj`.`t_user`.`user_name`  AS `user_name`,
    `compile`.`compile_result` AS `compile_result`,
    `submit`.`result`          AS `result`,
    `submit`.`time_consume`    AS `time_consume`,
    `submit`.`mem_consume`     AS `mem_consume`,
    `submit`.`language`        AS `language`,
    `submit`.`source_code`     AS `source_code`,
    `submit`.`code_length`     AS `code_length`,
    `submit`.`submit_time`     AS `submit_time`,
    `submit`.`judge_time`      AS `judge_time`
  FROM ((((`oj`.`t_submit_record` `submit` LEFT JOIN `oj`.`t_compile_info` `compile`
      ON ((`submit`.`submit_id` = `compile`.`submit_id`))) JOIN `oj`.`t_user`
      ON ((`submit`.`user_id` = `oj`.`t_user`.`user_id`))) JOIN `oj`.`t_problem`
      ON ((`submit`.`problem_id` = `oj`.`t_problem`.`problem_id`))) LEFT JOIN `oj`.`t_contest`
      ON ((`submit`.`contest_id` = `oj`.`t_contest`.`contest_id`)));

