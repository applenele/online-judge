CREATE FUNCTION isNum(str VARCHAR(25))
  RETURNS INT
  BEGIN
    DECLARE res INT DEFAULT 0;
    IF isnull(str) OR str='' THEN
      RETURN 0;
    END IF;
    SELECT str REGEXP '^[0-9]*$' INTO res;
    RETURN res;
  END;

